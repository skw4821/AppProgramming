import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:geolocator/geolocator.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:calender_project/widgets/calendar_widget.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

final FlutterLocalNotificationsPlugin notificationsPlugin = FlutterLocalNotificationsPlugin();

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await _initNotifications();
  runApp(MyApp());
}

Future<void> _initNotifications() async {
  const AndroidInitializationSettings androidInit = AndroidInitializationSettings('@mipmap/ic_launcher');
  const InitializationSettings initSettings = InitializationSettings(android: androidInit);
  await notificationsPlugin.initialize(initSettings);
}

class MyApp extends StatefulWidget {
  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  int _notificationIntensity = 1; // 1: 약함, 2: 중간, 3: 강함
  Position? _lastPosition;
  LatLng _targetLocation = const LatLng(37.5665, 126.9780); // 기본값: 서울

  @override
  void initState() {
    super.initState();
    _initLocationService();
  }

  Future<void> _initLocationService() async {
    await _checkLocationPermission();
    _startLocationStream();
    _scheduleMotivationNotification();
  }

  Future<void> _checkLocationPermission() async {
    LocationPermission permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission != LocationPermission.whileInUse &&
          permission != LocationPermission.always) {
        return;
      }
    }
  }

  void _startLocationStream() {
    Geolocator.getPositionStream(
      locationSettings: const LocationSettings(
        accuracy: LocationAccuracy.high,
        distanceFilter: 10,
      ),
    ).listen((Position position) {
      _handleLocationUpdate(position);
    });
  }

  void _handleLocationUpdate(Position position) {
    double distance = Geolocator.distanceBetween(
      position.latitude,
      position.longitude,
      _targetLocation.latitude,
      _targetLocation.longitude,
    );

    if (distance < 100) {
      if (_lastPosition == null || Geolocator.distanceBetween(
        _lastPosition!.latitude,
        _lastPosition!.longitude,
        _targetLocation.latitude,
        _targetLocation.longitude,
      ) >= 100) {
        _showNotification('도착 알림', '목표 위치에 도착했습니다!');
      }
    } else {
      if (_lastPosition != null && Geolocator.distanceBetween(
        _lastPosition!.latitude,
        _lastPosition!.longitude,
        _targetLocation.latitude,
        _targetLocation.longitude,
      ) < 100) {
        _showNotification('이탈 알림', '위치를 떠났습니다.');
      }
    }
    _lastPosition = position;
  }

  void _scheduleMotivationNotification() async {
    await notificationsPlugin.cancel(0); // 기존 알림 취소
    Duration interval;
    switch (_notificationIntensity) {
      case 1:
        interval = const Duration(hours: 1);
        break;
      case 2:
        interval = const Duration(minutes: 30);
        break;
      case 3:
        interval = const Duration(minutes: 15);
        break;
      default:
        interval = const Duration(hours: 1);
    }

    await notificationsPlugin.periodicallyShow(
      0,
      '동기부여 알림',
      '오늘도 화이팅! 할일을 잊지 마세요!',
      RepeatInterval.everyMinute, // 실제 구현 시 custom interval 필요
      const NotificationDetails(
        android: AndroidNotificationDetails(
          'motivation',
          '동기부여',
          importance: Importance.max,
        ),
      ),
      androidScheduleMode: AndroidScheduleMode.inexact,
    );
  }

  void _updateNotificationIntensity(int intensity) {
    setState(() => _notificationIntensity = intensity);
    _scheduleMotivationNotification();
  }

  void _showNotification(String title, String body) async {
    await notificationsPlugin.show(
      0,
      title,
      body,
      const NotificationDetails(
        android: AndroidNotificationDetails(
          'main',
          '메인 알림',
          importance: Importance.max,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: '위치 기반 캘린더',
      localizationsDelegates: [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      supportedLocales: const [Locale('ko', 'KR')],
      home: Scaffold(
        appBar: AppBar(
          title: const Text('위치 기반 캘린더'),
          actions: [
            IconButton(
              icon: const Icon(Icons.settings),
              onPressed: () => _showNotificationSettings(context),
            ),
          ],
        ),
        body: CalendarWidget(),
      ),
    );
  }

  void _showNotificationSettings(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('알림 설정'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [1, 2, 3].map((intensity) => RadioListTile(
            title: Text(_getIntensityLabel(intensity)),
            value: intensity,
            groupValue: _notificationIntensity,
            onChanged: (value) {
              _updateNotificationIntensity(value!);
              Navigator.pop(context);
            },
          )).toList(),
        ),
      ),
    );
  }

  String _getIntensityLabel(int level) {
    switch (level) {
      case 1: return '약함 (1시간 간격)';
      case 2: return '중간 (30분 간격)';
      case 3: return '강함 (15분 간격)';
      default: return '';
    }
  }
}
