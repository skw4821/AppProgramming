import 'package:flutter/material.dart';
import 'package:map_location_picker/map_location_picker.dart';
import 'package:geolocator/geolocator.dart';

class ScheduleInputDialog extends StatefulWidget {
  final DateTime selectedDate;
  const ScheduleInputDialog({super.key, required this.selectedDate});

  @override
  State<ScheduleInputDialog> createState() => _ScheduleInputDialogState();
}

class _ScheduleInputDialogState extends State<ScheduleInputDialog> {
  final _formKey = GlobalKey<FormState>();
  final _titleController = TextEditingController();
  final _locationController = TextEditingController();
  TimeOfDay? _startTime;
  TimeOfDay? _endTime;
  int _selectedIntensity = 1;

  Future<void> _pickStartTime() async {
    final time = await showTimePicker(
      context: context,
      initialTime: TimeOfDay.now(),
    );
    if (time != null) setState(() => _startTime = time);
  }

  Future<void> _pickEndTime() async {
    final time = await showTimePicker(
      context: context,
      initialTime: TimeOfDay.now(),
    );
    if (time != null) setState(() => _endTime = time);
  }

  Future<void> _pickLocation(BuildContext context) async {
    try {
      // 위치 서비스 활성화 확인
      bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
      if (!serviceEnabled) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('위치 서비스를 활성화해주세요')),
        );
        return;
      }

      // 위치 권한 확인
      LocationPermission permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
        if (permission == LocationPermission.denied) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('위치 권한이 필요합니다')),
          );
          return;
        }
      }

      // 현재 위치 가져오기
      Position position = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high,
      );

      // 통합 위치 선택 화면 띄우기 (검색 + 지도)
      final location = await Navigator.of(context).push(
        MaterialPageRoute(
          builder: (context) => MapLocationPicker(
            apiKey: "AIzaSyD0ZdEZLezrAmEWdAoeF88OZg0fDih99Po", // 본인 API 키로 변경!
            currentLatLng: LatLng(position.latitude, position.longitude),
            components: [Component(Component.country, "KR")],
            popOnNextButtonTaped: true,
            onNext: (GeocodingResult? result) {
              if (result != null) {
                _locationController.text =
                    result.formattedAddress ??
                        '${result.geometry?.location.lat}, ${result.geometry?.location.lng}';
              }
            },
          ),
        ),
      );
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('위치 정보를 가져오는데 실패했습니다: $e')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text('${widget.selectedDate.year}년 ${widget.selectedDate.month}월 ${widget.selectedDate.day}일 일정 추가'),
      content: Form(
        key: _formKey,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextFormField(
              controller: _titleController,
              decoration: const InputDecoration(labelText: '일정 제목'),
              validator: (value) => value!.isEmpty ? '제목을 입력해주세요' : null,
            ),
            TextFormField(
              controller: _locationController,
              decoration: InputDecoration(
                labelText: '위치',
                suffixIcon: IconButton(
                  icon: const Icon(Icons.search),
                  onPressed: () => _pickLocation(context),
                ),
              ),
              validator: (value) => value!.isEmpty ? '위치를 입력해주세요' : null,
            ),
            const SizedBox(height: 16),
            ListTile(
              title: const Text('시작 시간'),
              subtitle: Text(_startTime?.format(context) ?? '선택해주세요'),
              onTap: _pickStartTime,
            ),
            ListTile(
              title: const Text('종료 시간'),
              subtitle: Text(_endTime?.format(context) ?? '선택해주세요'),
              onTap: _pickEndTime,
            ),
          ],
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('취소'),
        ),
        TextButton(
          onPressed: () async {
            if (_formKey.currentState!.validate() &&
                _startTime != null &&
                _endTime != null) {
              final intensity = await showDialog<int>(
                context: context,
                builder: (context) => AlertDialog(
                  title: const Text('알림 강도 설정'),
                  content: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      RadioListTile(
                        title: const Text('약함 (1시간 간격)'),
                        value: 1,
                        groupValue: _selectedIntensity,
                        onChanged: (value) => Navigator.pop(context, value),
                      ),
                      RadioListTile(
                        title: const Text('중간 (30분 간격)'),
                        value: 2,
                        groupValue: _selectedIntensity,
                        onChanged: (value) => Navigator.pop(context, value),
                      ),
                      RadioListTile(
                        title: const Text('강함 (15분 간격)'),
                        value: 3,
                        groupValue: _selectedIntensity,
                        onChanged: (value) => Navigator.pop(context, value),
                      ),
                    ],
                  ),
                ),
              );
              if (intensity != null) {
                setState(() => _selectedIntensity = intensity);
                Navigator.pop(context, {
                  'title': _titleController.text,
                  'location': _locationController.text,
                  'start_time': _startTime!.format(context),
                  'end_time': _endTime!.format(context),
                  'intensity': intensity,
                });
              }
            } else {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('모든 항목을 입력해주세요')),
              );
            }
          },
          child: const Text('저장'),
        ),
      ],
    );
  }
}
